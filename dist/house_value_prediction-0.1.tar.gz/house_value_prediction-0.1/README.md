Median housing value prediction code is available in this repo

## To excute the script
python nonstandardcode.py