import house_value_prediction
import house_value_prediction.ingest_data
import house_value_prediction.score
import house_value_prediction.train

print("Installation done successfully")
